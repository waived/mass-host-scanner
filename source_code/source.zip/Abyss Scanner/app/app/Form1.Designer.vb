﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPath = New System.Windows.Forms.TextBox()
        Me.lnkGen = New System.Windows.Forms.LinkLabel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPorts = New System.Windows.Forms.TextBox()
        Me.numSleep = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.numThdz = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.numTout = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnImport = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.listInfo = New System.Windows.Forms.ListBox()
        Me.btnCtrl = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lbTotal = New System.Windows.Forms.Label()
        Me.lbOpen = New System.Windows.Forms.Label()
        Me.lbClosed = New System.Windows.Forms.Label()
        Me.lnkGithub = New System.Windows.Forms.LinkLabel()
        Me.exportMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tabExport = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        CType(Me.numSleep, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numThdz, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numTout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.exportMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPath)
        Me.GroupBox1.Controls.Add(Me.lnkGen)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtPorts)
        Me.GroupBox1.Controls.Add(Me.numSleep)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.numThdz)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.numTout)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btnImport)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(329, 165)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Settings"
        '
        'txtPath
        '
        Me.txtPath.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.txtPath.ForeColor = System.Drawing.Color.White
        Me.txtPath.Location = New System.Drawing.Point(61, 24)
        Me.txtPath.Name = "txtPath"
        Me.txtPath.ReadOnly = True
        Me.txtPath.Size = New System.Drawing.Size(214, 20)
        Me.txtPath.TabIndex = 1
        '
        'lnkGen
        '
        Me.lnkGen.ActiveLinkColor = System.Drawing.Color.Black
        Me.lnkGen.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lnkGen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lnkGen.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.lnkGen.LinkColor = System.Drawing.Color.WhiteSmoke
        Me.lnkGen.Location = New System.Drawing.Point(60, 44)
        Me.lnkGen.Name = "lnkGen"
        Me.lnkGen.Size = New System.Drawing.Size(179, 15)
        Me.lnkGen.TabIndex = 17
        Me.lnkGen.TabStop = True
        Me.lnkGen.Text = "Generate"
        Me.lnkGen.VisitedLinkColor = System.Drawing.Color.WhiteSmoke
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Port/s:"
        '
        'txtPorts
        '
        Me.txtPorts.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.txtPorts.ForeColor = System.Drawing.Color.White
        Me.txtPorts.Location = New System.Drawing.Point(61, 74)
        Me.txtPorts.Name = "txtPorts"
        Me.txtPorts.Size = New System.Drawing.Size(214, 20)
        Me.txtPorts.TabIndex = 1
        Me.txtPorts.Text = "80, 443, 3389"
        '
        'numSleep
        '
        Me.numSleep.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.numSleep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.numSleep.ForeColor = System.Drawing.Color.White
        Me.numSleep.Location = New System.Drawing.Point(215, 128)
        Me.numSleep.Maximum = New Decimal(New Integer() {1410065407, 2, 0, 0})
        Me.numSleep.Name = "numSleep"
        Me.numSleep.Size = New System.Drawing.Size(60, 20)
        Me.numSleep.TabIndex = 5
        Me.numSleep.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(212, 112)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Sleep M/s"
        '
        'numThdz
        '
        Me.numThdz.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.numThdz.Cursor = System.Windows.Forms.Cursors.Hand
        Me.numThdz.ForeColor = System.Drawing.Color.White
        Me.numThdz.Location = New System.Drawing.Point(141, 128)
        Me.numThdz.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.numThdz.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numThdz.Name = "numThdz"
        Me.numThdz.Size = New System.Drawing.Size(60, 20)
        Me.numThdz.TabIndex = 3
        Me.numThdz.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(138, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Thread/s"
        '
        'numTout
        '
        Me.numTout.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.numTout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.numTout.ForeColor = System.Drawing.Color.White
        Me.numTout.Location = New System.Drawing.Point(61, 128)
        Me.numTout.Maximum = New Decimal(New Integer() {1215752191, 23, 0, 0})
        Me.numTout.Minimum = New Decimal(New Integer() {100, 0, 0, 0})
        Me.numTout.Name = "numTout"
        Me.numTout.Size = New System.Drawing.Size(65, 20)
        Me.numTout.TabIndex = 1
        Me.numTout.Value = New Decimal(New Integer() {1500, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(58, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Timeout M/s"
        '
        'btnImport
        '
        Me.btnImport.BackColor = System.Drawing.Color.Black
        Me.btnImport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnImport.Location = New System.Drawing.Point(283, 22)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.Size = New System.Drawing.Size(27, 23)
        Me.btnImport.TabIndex = 1
        Me.btnImport.Text = "..."
        Me.btnImport.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "IP List:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 188)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Result/s"
        '
        'listInfo
        '
        Me.listInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.listInfo.ContextMenuStrip = Me.exportMenu
        Me.listInfo.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.listInfo.FormattingEnabled = True
        Me.listInfo.HorizontalScrollbar = True
        Me.listInfo.Location = New System.Drawing.Point(12, 204)
        Me.listInfo.Name = "listInfo"
        Me.listInfo.ScrollAlwaysVisible = True
        Me.listInfo.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.listInfo.Size = New System.Drawing.Size(329, 147)
        Me.listInfo.TabIndex = 9
        '
        'btnCtrl
        '
        Me.btnCtrl.BackColor = System.Drawing.Color.Black
        Me.btnCtrl.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCtrl.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCtrl.Location = New System.Drawing.Point(227, 357)
        Me.btnCtrl.Name = "btnCtrl"
        Me.btnCtrl.Size = New System.Drawing.Size(114, 26)
        Me.btnCtrl.TabIndex = 8
        Me.btnCtrl.Text = "SCAN"
        Me.btnCtrl.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 357)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "# host/s:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 380)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "# open:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 403)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(51, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "# closed:"
        '
        'lbTotal
        '
        Me.lbTotal.AutoSize = True
        Me.lbTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbTotal.Location = New System.Drawing.Point(67, 357)
        Me.lbTotal.Name = "lbTotal"
        Me.lbTotal.Size = New System.Drawing.Size(14, 13)
        Me.lbTotal.TabIndex = 13
        Me.lbTotal.Text = "0"
        '
        'lbOpen
        '
        Me.lbOpen.AutoSize = True
        Me.lbOpen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbOpen.Location = New System.Drawing.Point(67, 380)
        Me.lbOpen.Name = "lbOpen"
        Me.lbOpen.Size = New System.Drawing.Size(14, 13)
        Me.lbOpen.TabIndex = 14
        Me.lbOpen.Text = "0"
        '
        'lbClosed
        '
        Me.lbClosed.AutoSize = True
        Me.lbClosed.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbClosed.Location = New System.Drawing.Point(67, 403)
        Me.lbClosed.Name = "lbClosed"
        Me.lbClosed.Size = New System.Drawing.Size(14, 13)
        Me.lbClosed.TabIndex = 15
        Me.lbClosed.Text = "0"
        '
        'lnkGithub
        '
        Me.lnkGithub.ActiveLinkColor = System.Drawing.Color.Black
        Me.lnkGithub.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lnkGithub.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lnkGithub.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.lnkGithub.LinkColor = System.Drawing.Color.WhiteSmoke
        Me.lnkGithub.Location = New System.Drawing.Point(12, 416)
        Me.lnkGithub.Name = "lnkGithub"
        Me.lnkGithub.Size = New System.Drawing.Size(328, 30)
        Me.lnkGithub.TabIndex = 16
        Me.lnkGithub.TabStop = True
        Me.lnkGithub.Text = "https://github.com/waived"
        Me.lnkGithub.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lnkGithub.VisitedLinkColor = System.Drawing.Color.WhiteSmoke
        '
        'exportMenu
        '
        Me.exportMenu.BackColor = System.Drawing.Color.Black
        Me.exportMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tabExport})
        Me.exportMenu.Name = "ContextMenuStrip1"
        Me.exportMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.exportMenu.ShowImageMargin = False
        Me.exportMenu.Size = New System.Drawing.Size(156, 48)
        '
        'tabExport
        '
        Me.tabExport.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.tabExport.Name = "tabExport"
        Me.tabExport.Size = New System.Drawing.Size(155, 22)
        Me.tabExport.Text = "Export to TXT"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(353, 455)
        Me.Controls.Add(Me.lnkGithub)
        Me.Controls.Add(Me.lbClosed)
        Me.Controls.Add(Me.lbOpen)
        Me.Controls.Add(Me.lbTotal)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnCtrl)
        Me.Controls.Add(Me.listInfo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Abyss 1.9"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.numSleep, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numThdz, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numTout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.exportMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents numTout As NumericUpDown
    Friend WithEvents Label2 As Label
    Friend WithEvents btnImport As Button
    Friend WithEvents txtPath As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents numSleep As NumericUpDown
    Friend WithEvents Label4 As Label
    Friend WithEvents numThdz As NumericUpDown
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtPorts As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents listInfo As ListBox
    Friend WithEvents btnCtrl As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lbTotal As Label
    Friend WithEvents lbOpen As Label
    Friend WithEvents lbClosed As Label
    Friend WithEvents lnkGithub As LinkLabel
    Friend WithEvents lnkGen As LinkLabel
    Friend WithEvents exportMenu As ContextMenuStrip
    Friend WithEvents tabExport As ToolStripMenuItem
End Class
