﻿Imports System, System.IO, System.Threading.Threading
Imports System.Threading
Public Class Form2
    Private _path As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim _sfd As New SaveFileDialog
        _sfd.FileName = "ips.txt"
        _sfd.Filter = "Text Files|*.txt"

        If _sfd.ShowDialog = DialogResult.OK Then
            _path = _sfd.FileName

            numCount.ReadOnly = True

            System.Threading.ThreadPool.QueueUserWorkItem(Sub() _worker())
        End If
    End Sub

    Private Sub _worker()
        CheckForIllegalCrossThreadCalls = False

        Dim _ipv4 As String
        Try
            Using writer As New StreamWriter(_path, False)
                For i As Integer = 1 To numCount.Value

                    _ipv4 = gen_ip()

                    Me.Text = "Generated ---> " + _ipv4

                    writer.WriteLine(_ipv4)

                    Thread.Sleep(50)

                Next
                writer.Close()
            End Using

            Form1.txtPath.Text = _path

            Me.Hide()
            MessageBox.Show("Done!", "", MessageBoxButtons.OK)
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Critical error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Function gen_ip() As String
        Dim random As New Random()
        Dim octet1, octet2, octet3, octet4 As Integer

        While True
            octet1 = random.Next(0, 256)
            octet2 = random.Next(0, 256)
            octet3 = random.Next(0, 256)
            octet4 = random.Next(0, 256)

            ' avoid private ips, broacast/subnet addresses, etc
            If Not (octet1 = 10 OrElse (octet1 = 172 AndAlso octet2 >= 16 AndAlso octet2 <= 31) OrElse (octet1 = 192 AndAlso octet2 = 168)) Then
                Exit While
            End If
        End While

        Return $"{octet1}.{octet2}.{octet3}.{octet4}"
    End Function
End Class