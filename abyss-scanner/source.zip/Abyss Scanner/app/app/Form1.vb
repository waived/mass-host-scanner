﻿Imports System.Net.Sockets, System.IO
Imports System.Security.Cryptography
Imports System.Threading

Public Class Form1

    Private _active As Boolean = False
    Private _running As Integer = 0
    Private intBad, intOk, intTotal As Integer
    Public _targets As New List(Of String)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Form1_Closing(sender As Object, e As EventArgs) Handles MyBase.Closing
        _active = False
    End Sub

    Private Sub lnkGen_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkGen.LinkClicked
        If Not _active = True Then
            Form2.Show()
        End If
    End Sub

    Private Sub lnkGithub_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkGithub.LinkClicked
        Process.Start("https://github.com/waived")
    End Sub

    Private Sub btnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
        If Not _active = True Then
            Dim _ofd As New OpenFileDialog
            _ofd.Filter = "Text Files|*.txt"

            If _ofd.ShowDialog = DialogResult.OK Then
                _import(_ofd.FileName.ToString)
            End If
        End If
    End Sub

    Private Sub _import(ofdpath As String)
        Try
            _targets.AddRange(File.ReadAllLines(ofdpath))
            txtPath.Text = ofdpath
        Catch ex As Exception
            MessageBox.Show("Error accessing list! Verify your permissions.", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnCtrl_Click(sender As Object, e As EventArgs) Handles btnCtrl.Click
        If btnCtrl.Text = "SCAN" Then
            'begin
            If String.IsNullOrEmpty(txtPath.Text) Then
                MessageBox.Show("Error! IP list must be specified.", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf String.IsNullOrEmpty(txtPorts.Text) Then
                MessageBox.Show("Error! At least one port value must be specified.", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                btnCtrl.Text = "ABORT"

                _active = True

                System.Threading.ThreadPool.QueueUserWorkItem(Sub() _manage())
            End If

        ElseIf btnCtrl.Text = "ABORT" Then
            'cancel
            _active = False

            btnCtrl.Enabled = False

            _reset()

        End If
    End Sub

    Private Function _manage()
        CheckForIllegalCrossThreadCalls = False

        'list of ports to be scanned
        Dim _values As String = txtPorts.Text.Replace(" ", "")
        Dim _ports As String() = _values.Split(","c)

        'iterate through host list
        For Each _targ As String In _targets

            intTotal += 1
            lbTotal.Text = intTotal.ToString

            ' abort if required
            If _active = False Then
                Exit For
            End If

            'iterate through port list
            For Each _port As String In _ports
                ' abort if required
                If _active = False Then
                    Exit For
                End If

                'scan port
                Dim t As New Thread(Sub() Me._scan(_targ, Int(_port)))
                t.Start()
                ' enforce thread-cap
                Do
                    If _running < numThdz.Value Then
                        Exit Do
                    End If
                Loop

            Next

        Next

        'reset form fields/controls
        _reset()

    End Function

    Private Sub tabExport_Click(sender As Object, e As EventArgs) Handles tabExport.Click
        CheckForIllegalCrossThreadCalls = False

        If _active = True Then
            MessageBox.Show("Cannot export results until active scan is complete.", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            If listInfo.Items.Count = 0 Then
                MessageBox.Show("Nothing to export!", "Alert!", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                Dim result As DialogResult = MessageBox.Show("Export results to .txt file?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If result = DialogResult.Yes Then
                    Dim _sfd As New SaveFileDialog
                    _sfd.FileName = "Results.txt"
                    _sfd.Filter = "Text Files|*.txt"

                    If _sfd.ShowDialog = DialogResult.OK Then
                        Using writer As New StreamWriter(_sfd.FileName)
                            ' Loop through each item in the ListBox
                            For Each item As String In listInfo.Items
                                ' Write the item to the file
                                writer.WriteLine(item)
                            Next
                        End Using
                    End If
                End If
            End If
        End If
    End Sub

    Private Function _reset()
        CheckForIllegalCrossThreadCalls = False

        MessageBox.Show("Done!", "", MessageBoxButtons.OK, MessageBoxIcon.Information)

        intBad = 0
        intOk = 0
        intTotal = 0
        txtPath.Clear()
        txtPorts.Text = "80, 443, 3389"
        numTout.Value = 1500
        numThdz.Value = 10
        numSleep.Value = 100
        'listInfo.Items.Clear()
        'lbClosed.Text = "0"
        'lbOpen.Text = "0"
        'lbTotal.Text = "0"
        btnCtrl.Enabled = True
        btnCtrl.Text = "SCAN"
    End Function

    Private Async Sub _scan(_ip As String, _prt As Integer)
        CheckForIllegalCrossThreadCalls = False

        _running += 1

        Try
            Dim client As New TcpClient()
            Dim result = client.BeginConnect(_ip, _prt, Nothing, Nothing)
            Dim success = result.AsyncWaitHandle.WaitOne(TimeSpan.FromMilliseconds(numTout.Value))
            If Not success Then
                intBad += 1
                lbClosed.Text = intBad.ToString
            Else
                intOk += 1
                lbOpen.Text = intOk.ToString

                listInfo.Items.Add("Port open @ " + _ip + ":" + _prt.ToString)
            End If
        Catch ex As Exception
            intBad += 1
            lbClosed.Text = intBad.ToString
        End Try

        _running -= 1
    End Sub
End Class
